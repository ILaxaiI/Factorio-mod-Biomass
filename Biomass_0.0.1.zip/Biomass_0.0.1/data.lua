data:extend({
    {
        type = "recipe-category",
        name = "growth-vat-crafting"
    },
    {
        type = "damage-type",
        name = "scourge"
    }
})
require("prototypes.entities.biomass")
require("prototypes.entities.entities")
require("prototypes.recipes.recipes")
require("prototypes.items")
require("prototypes.fluid")
require("prototypes.warheads")
require("prototypes.technology")
require("prototypes.cleanup_tool")